<?php use App\Flash; ?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="/css/style.css">
</head>

<body>

	<div class="main">

		<!-- Sing in  Form -->
		<section class="sign-in">
			<div class="container">
				<div class="signin-content">
					<div class="signin-image">
						<figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
					</div>

					<div class="signin-form">
						<h2 class="form-title">Forgot Password</h2>
						<form method="POST" action="/Password/reset" class="register-form" id="login-form">
							<div class="form-group">
								<label for="otp"><i class="zmdi zmdi-email"></i></label>
								<input type="number" name="otp" id="email" placeholder="Your OTP" />
							</div>
							<div class="form-group">
								<label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
								<input type="password" name="your_pass" id="your_pass" placeholder="Password" />
							</div>
							<div class="form-group">
								<label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
								<input type="password" name="re_pass" id="re_pass" placeholder="Repeat your password" />
							</div>
							<div class="form-group form-button">
								<input type="submit" name="signin" id="signin" class="form-submit" value="Submit" />
								<a href="/signup.php" class="signup-image-link">Create an account</a>
							</div>
						</form>
					</div>
				</div>
			</div>
		</section>

	</div>
	<script src="/js/forget-password.js"></script>
	
</body>

</html>