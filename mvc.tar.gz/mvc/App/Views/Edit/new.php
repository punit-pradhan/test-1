
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SQuora</title>
  <link rel="icon" type="image/x-icon" href="/image/SQuora.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="/css/feed.css">
</head>
<body>
  <header>
    <div class="container">
      <nav class="flex-justify-between">
        <div class="head-left">
          <a href="/Feed/new"><img src="/image/SQuora.png" alt="logo"></a>
        </div>
        <div class="head-right">
          <a href="/Userprofile/create"><i class="fa-solid fa-user"></i></a>
        </div>
      </nav>
    </div>
  </header>
  <main>
    <?php
    $user=$_SESSION['username'];
    if($user==$row["username"]){
    ?>
    <div class="container">
      <section class="feed-questions">
      <form action="/Edit/create?id=<?php echo $row['id'];?>" method="POST">
      <label for="app_name">App Name:</label>
    <input type="text" name="app_name" id="app_name">
    <br><br>
    <label for="app_desc">App Description:</label>
    <textarea name="app_desc" id="app_desc" rows="4" cols="50"></textarea>
    <br><br>
    <label for="developer">Developer Name:</label>
    <input type="text" name="developer" id="developer">
    <br><br>
    <label for="app_file">APK File:</label>
    <input type="file" name="app_file" id="app_file">
    <br><br>
    <input type="submit" value="Upload App">
      </form>
      </section>
    </div>
  </main>
  <?php
  }
  else{
    header('Location:/Feed/view');
  }
  ?>
</body>
</html>